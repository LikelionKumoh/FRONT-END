import React from 'react';

const Home = () => {
    return (
        <div>
            <h1 style={{color:'#08088A', textAlign:'center'}}>LIKE LION UNIV. x K.I.T UNIV.</h1>
            <img src='/img/Home_image.jpg' />
        </div>
    );
};

export default Home;